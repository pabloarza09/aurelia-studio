"""Endpoints CRUD del recurso Colección."""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.db.session import get_db
from app.models.collection import Collection
from app.models.user import User
from app.schemas.collection import CollectionCreate, CollectionRead

router = APIRouter()


@router.get("", response_model=list[CollectionRead])
async def list_collections(db: AsyncSession = Depends(get_db)) -> list[Collection]:
    result = await db.execute(select(Collection).order_by(Collection.created_at.desc()))
    return list(result.scalars().all())


@router.post("", response_model=CollectionRead, status_code=status.HTTP_201_CREATED)
async def create_collection(
    payload: CollectionCreate,
    db: AsyncSession = Depends(get_db),
    _current_user: User = Depends(get_current_user),
) -> Collection:
    existing = await db.execute(select(Collection).where(Collection.slug == payload.slug))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="El slug ya existe")

    collection = Collection(**payload.model_dump())
    db.add(collection)
    await db.commit()
    await db.refresh(collection)
    return collection
