"""Configuración central de la aplicación, leída desde variables de entorno."""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    APP_NAME: str = "Aurelia OS API"
    APP_VERSION: str = "0.1.0"
    ENVIRONMENT: str = "development"
    LOG_LEVEL: str = "INFO"

    # Base de datos
    DATABASE_URL: str = "postgresql+asyncpg://aurelia:aurelia@localhost:5432/aurelia_os"

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"

    # Seguridad
    SECRET_KEY: str = "dev-only-insecure-key-change-me-before-deploying-to-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    # CORS
    CORS_ORIGINS: list[str] = ["http://localhost:3000"]


@lru_cache
def get_settings() -> Settings:
    return Settings()
