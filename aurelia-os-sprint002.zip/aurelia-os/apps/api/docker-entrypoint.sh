#!/bin/sh
set -e

echo "Aplicando migraciones (alembic upgrade head)..."
alembic upgrade head

echo "Iniciando Aurelia OS API..."
exec uvicorn app.main:app --host 0.0.0.0 --port 8000
