async def test_create_product_requires_auth(client):
    payload = {
        "name": "Sin auth",
        "slug": "sin-auth",
        "category": "academic",
        "price_usd": 5,
        "status": "draft",
    }
    response = await client.post("/api/v1/products", json=payload)
    assert response.status_code == 401


async def test_create_and_list_product(client, auth_headers):
    payload = {
        "name": "Academic Planner Premium",
        "slug": "academic-planner-premium",
        "category": "academic",
        "price_usd": 12.5,
        "status": "draft",
    }

    create_response = await client.post("/api/v1/products", json=payload, headers=auth_headers)
    assert create_response.status_code == 201
    created = create_response.json()
    assert created["name"] == payload["name"]
    assert "id" in created

    list_response = await client.get("/api/v1/products")
    assert list_response.status_code == 200
    items = list_response.json()
    assert len(items) == 1
    assert items[0]["slug"] == payload["slug"]


async def test_create_duplicate_slug_returns_409(client, auth_headers):
    payload = {
        "name": "Duplicado",
        "slug": "duplicado",
        "category": "academic",
        "price_usd": 5,
        "status": "draft",
    }
    await client.post("/api/v1/products", json=payload, headers=auth_headers)
    second = await client.post("/api/v1/products", json=payload, headers=auth_headers)
    assert second.status_code == 409


async def test_get_nonexistent_product_returns_404(client):
    response = await client.get("/api/v1/products/00000000-0000-0000-0000-000000000000")
    assert response.status_code == 404
