async def test_register_creates_user(client):
    response = await client.post(
        "/auth/register",
        json={
            "email": "nueva@aurelia.studio",
            "password": "supersecreta123",
            "full_name": "Nueva Usuaria",
        },
    )
    assert response.status_code == 201
    body = response.json()
    assert body["email"] == "nueva@aurelia.studio"
    assert "hashed_password" not in body  # nunca debe filtrarse el hash


async def test_register_duplicate_email_returns_409(client):
    payload = {
        "email": "duplicada@aurelia.studio",
        "password": "supersecreta123",
        "full_name": "Duplicada",
    }
    await client.post("/auth/register", json=payload)
    second = await client.post("/auth/register", json=payload)
    assert second.status_code == 409


async def test_login_with_correct_credentials_returns_token(client):
    await client.post(
        "/auth/register",
        json={
            "email": "login@aurelia.studio",
            "password": "supersecreta123",
            "full_name": "Login Test",
        },
    )
    response = await client.post(
        "/auth/login",
        data={"username": "login@aurelia.studio", "password": "supersecreta123"},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["token_type"] == "bearer"
    assert len(body["access_token"]) > 20


async def test_login_with_wrong_password_returns_401(client):
    await client.post(
        "/auth/register",
        json={
            "email": "wrongpass@aurelia.studio",
            "password": "supersecreta123",
            "full_name": "Wrong Pass",
        },
    )
    response = await client.post(
        "/auth/login",
        data={"username": "wrongpass@aurelia.studio", "password": "incorrecta"},
    )
    assert response.status_code == 401


async def test_me_without_token_returns_401(client):
    response = await client.get("/auth/me")
    assert response.status_code == 401


async def test_me_with_valid_token_returns_current_user(client, auth_headers):
    response = await client.get("/auth/me", headers=auth_headers)
    assert response.status_code == 200
    assert response.json()["email"] == "tester@aurelia.studio"
