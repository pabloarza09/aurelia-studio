async def test_create_collection_requires_auth(client):
    response = await client.post(
        "/api/v1/collections",
        json={"name": "Academic", "slug": "academic", "description": "Planners académicos"},
    )
    assert response.status_code == 401


async def test_create_and_list_collection(client, auth_headers):
    payload = {"name": "Academic", "slug": "academic", "description": "Planners académicos"}
    create_response = await client.post(
        "/api/v1/collections", json=payload, headers=auth_headers
    )
    assert create_response.status_code == 201

    list_response = await client.get("/api/v1/collections")
    assert list_response.status_code == 200
    items = list_response.json()
    assert len(items) == 1
    assert items[0]["slug"] == "academic"


async def test_create_duplicate_collection_slug_returns_409(client, auth_headers):
    payload = {"name": "Business", "slug": "business", "description": ""}
    await client.post("/api/v1/collections", json=payload, headers=auth_headers)
    second = await client.post("/api/v1/collections", json=payload, headers=auth_headers)
    assert second.status_code == 409


async def test_product_can_reference_collection(client, auth_headers):
    collection_response = await client.post(
        "/api/v1/collections",
        json={"name": "Wellness", "slug": "wellness", "description": ""},
        headers=auth_headers,
    )
    collection_id = collection_response.json()["id"]

    product_response = await client.post(
        "/api/v1/products",
        json={
            "name": "Wellness Planner",
            "slug": "wellness-planner",
            "category": "wellness",
            "price_usd": 9.99,
            "status": "draft",
            "collection_id": collection_id,
        },
        headers=auth_headers,
    )
    assert product_response.status_code == 201
    assert product_response.json()["collection_id"] == collection_id
