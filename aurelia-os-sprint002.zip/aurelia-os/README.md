# Aurelia OS

Plataforma central de Aurelia Studio: API, dashboard y la base sobre la que se
construirán los productos, automatizaciones y agentes de IA del negocio.

Este repositorio es el **Sprint 001 (Foundation)**: un monorepo ejecutable,
no una maqueta. Cada pieza descrita abajo fue instalada, compilada y probada
antes de entregarse — ver [Estado verificado](#estado-verificado).

## Arquitectura

```
┌─────────────────────────────┐
│   Next.js Dashboard (3000)  │
└──────────────┬──────────────┘
               │ HTTP
┌──────────────┴──────────────┐
│    FastAPI API (8000)       │
│  /health/live  /health/ready│
│  /auth/register /auth/login │
│  /auth/me                   │
│  /api/v1/products            │
│  /api/v1/collections         │
└───┬───────────────────┬─────┘
    │                   │
PostgreSQL (5432)   Redis (6379)
(+ pgvector, migrado con Alembic)
```

- **apps/api** — FastAPI, SQLAlchemy async, PostgreSQL (con extensión
  pgvector lista para embeddings/IA) migrado con Alembic, Redis, logging
  estructurado en JSON, health checks de liveness y readiness,
  autenticación JWT (registro, login, `/me`).
- **apps/dashboard** — Next.js 16 (App Router, Turbopack), TypeScript,
  consume la API y aplica el tema oscuro + dorado de Aurelia Design System.

## Requisitos

- Docker y Docker Compose (recomendado para levantar todo el stack).
- Alternativamente, para desarrollo sin Docker: Python 3.12+ y Node.js 20+.

## Puesta en marcha (Docker)

```bash
cp .env.example .env   # ya viene copiado como .env en esta entrega
docker compose up --build
```

Al levantar, la API aplica las migraciones de Alembic automáticamente
(`docker-entrypoint.sh`) antes de arrancar — no hace falta correrlas a mano.

Al terminar de levantar:

- Dashboard: http://localhost:3000
- API: http://localhost:8000
- Documentación OpenAPI: http://localhost:8000/docs
- Liveness: http://localhost:8000/health/live
- Readiness (chequea Postgres y Redis): http://localhost:8000/health/ready

`docker compose down` detiene todo. `make clean` elimina además volúmenes e
imágenes locales.

### Probar el flujo de autenticación

```bash
# Registro
curl -X POST http://localhost:8000/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"vos@aurelia.studio","password":"tu-password-segura","full_name":"Tu Nombre"}'

# Login (devuelve un access_token)
curl -X POST http://localhost:8000/auth/login \
  -d "username=vos@aurelia.studio&password=tu-password-segura"

# Usar el token en endpoints protegidos (crear producto/colección)
curl -X POST http://localhost:8000/api/v1/collections \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <access_token>" \
  -d '{"name":"Academic","slug":"academic","description":"Planners académicos"}'
```

`GET /api/v1/products` y `GET /api/v1/collections` son públicos; los `POST`
de ambos recursos requieren el header `Authorization: Bearer <token>`.

## Desarrollo sin Docker

**Backend:**

```bash
cd apps/api
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
alembic upgrade head   # requiere Postgres corriendo (ver docker-compose.yml)
uvicorn app.main:app --reload
```

Sin Postgres/Redis corriendo localmente, `/health/live` responde igual;
`/health/ready` informa `"degraded"` con el detalle de qué servicio falta —
no rompe la aplicación. Los endpoints que sí tocan la base (auth, products,
collections) necesitan la base migrada y corriendo.

Para generar una nueva migración después de modificar un modelo:

```bash
make migration m="descripción del cambio"
make migrate
```

**Frontend:**

```bash
cd apps/dashboard
npm install
npm run dev
```

## Testing y calidad

```bash
make test    # pytest (backend)
make lint    # ruff (backend) + eslint (frontend)
```

## Estructura del monorepo

```
.
├── apps/
│   ├── api/                  # FastAPI
│   │   ├── app/
│   │   │   ├── api/
│   │   │   │   ├── routes/   # health.py, auth.py, products.py, collections.py
│   │   │   │   └── deps.py   # get_current_user
│   │   │   ├── core/         # config.py, logging.py, security.py (JWT/hashing)
│   │   │   ├── db/           # session.py, base.py
│   │   │   ├── models/       # user.py, collection.py, product.py (SQLAlchemy)
│   │   │   ├── schemas/      # user.py, collection.py, product.py (Pydantic)
│   │   │   └── main.py
│   │   ├── migrations/        # Alembic (async), versions/0001_initial...
│   │   ├── tests/             # pytest + SQLite en memoria, incluye fixture auth_headers
│   │   ├── alembic.ini
│   │   ├── docker-entrypoint.sh  # corre migraciones y arranca uvicorn
│   │   ├── pyproject.toml
│   │   └── Dockerfile
│   └── dashboard/             # Next.js 16 (App Router)
│       ├── app/                # layout.tsx, page.tsx, globals.css
│       ├── lib/api.ts           # cliente HTTP hacia la API
│       ├── package.json
│       └── Dockerfile
├── .github/workflows/ci.yml   # lint + migraciones contra Postgres real + tests + build
├── docker-compose.yml
├── Makefile
├── .env.example
└── package.json                # workspace root (npm)
```

## Variables de entorno

Ver `.env.example` para el listado completo y comentado. Las más relevantes:

| Variable | Uso |
|---|---|
| `DATABASE_URL` | Conexión async a PostgreSQL (SQLAlchemy + asyncpg) |
| `REDIS_URL` | Conexión a Redis |
| `SECRET_KEY` | Clave de firma JWT — **cambiar antes de producción** |
| `ALGORITHM` | Algoritmo de firma JWT (HS256 por defecto) |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | Vigencia del access token en minutos |
| `NEXT_PUBLIC_API_URL` | URL de la API que consume el dashboard |

## Estado verificado

Todo lo listado abajo se ejecutó realmente en el entorno de build, no es una
descripción aspiracional:

**Sprint 001:**
- ✅ Backend: `pip install -e ".[dev]"` sin errores.
- ✅ Backend: `ruff check` sin errores.
- ✅ Backend: servidor real (`uvicorn`) arrancado, `/health/live` y
  `/openapi.json` respondidos correctamente; `/health/ready` degrada con
  gracia cuando Postgres/Redis no están disponibles (no crashea).
- ✅ Frontend: `npm install`/`npm ci` sin conflictos de dependencias ni
  vulnerabilidades reportadas (Next.js 16.2.10 / React 19.2.4, líneas con
  soporte activo).
- ✅ Frontend: `next build` sin errores ni warnings; `eslint` sin errores.
- ✅ Frontend: servidor de producción (`next start`) probado — degrada con
  gracia cuando la API no está disponible.
- ✅ `docker-compose.yml` y `ci.yml` validados como YAML bien formado.

**Sprint 002 (auth + modelos de dominio):**
- ✅ 15/15 tests (`pytest`) en verde: registro, login (credenciales
  correctas/incorrectas), `/me` con y sin token, creación de productos y
  colecciones protegida (401 sin token), slugs/emails duplicados (409),
  producto referenciando una colección.
- ✅ `ruff check` sin errores (incluye `migrations/env.py`; los archivos
  autogenerados en `migrations/versions/` quedan excluidos del lint por
  convención estándar).
- ✅ Flujo completo probado a mano contra un servidor real (no solo tests
  aislados): registro → login → `/me` → crear colección → crear producto
  vinculado → rechazo sin token → rechazo con contraseña incorrecta.
- ✅ Migración inicial de Alembic (`users`, `collections`, `products` + FK
  + índices únicos) generada por autogenerate, y el ciclo `upgrade head` /
  `downgrade base` corrido de punta a punta contra una base real (SQLite
  local, ya que este entorno no tiene Postgres disponible — ver nota
  abajo). El paso de migraciones en CI sí corre contra Postgres real
  (servicio de GitHub Actions).
- ✅ `docker-entrypoint.sh` (migra y luego levanta uvicorn) simulado y
  verificado paso a paso.
- ⚠️ No verificado en este entorno: `docker compose up` de punta a punta,
  ni `alembic upgrade head` contra el Postgres real del compose (el sandbox
  no tiene Docker). Si corriste el checkpoint de Sprint 001 con éxito, este
  paso solo agrega el entrypoint de migraciones al mismo flujo ya probado.

## Próximos sprints

- **Sprint 003 — Dashboard:** vistas reales sobre `apps/dashboard` (login,
  listado de productos y colecciones, métricas), usando los 26 componentes
  ya especificados en el Design System (Navegación, Dashboard, Calendarios,
  Portadas) y consumiendo `/auth`, `/api/v1/products`, `/api/v1/collections`.
- **Sprint 004 — AI Runtime:** agentes sobre pgvector para automatizar
  generación de contenido y componentes.
- **Sprint 005 — Product Factory / Sprint 006 — MVP.**
