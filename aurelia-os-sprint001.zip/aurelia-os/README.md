# Aurelia OS

Plataforma central de Aurelia Studio: API, dashboard y la base sobre la que se
construirán los productos, automatizaciones y agentes de IA del negocio.

Este repositorio es el **Sprint 001 (Foundation)**: un monorepo ejecutable,
no una maqueta. Cada pieza descrita abajo fue instalada, compilada y probada
antes de entregarse — ver [Estado verificado](#estado-verificado).

## Arquitectura

```
┌─────────────────────────────┐
│   Next.js Dashboard (3000)  │
└──────────────┬──────────────┘
               │ HTTP
┌──────────────┴──────────────┐
│    FastAPI API (8000)       │
│  /health/live  /health/ready│
│  /api/v1/products            │
└───┬───────────────────┬─────┘
    │                   │
PostgreSQL (5432)   Redis (6379)
(+ pgvector)
```

- **apps/api** — FastAPI, SQLAlchemy async, PostgreSQL (con extensión
  pgvector lista para embeddings/IA), Redis, logging estructurado en JSON,
  health checks de liveness y readiness.
- **apps/dashboard** — Next.js 16 (App Router, Turbopack), TypeScript,
  consume la API y aplica el tema oscuro + dorado de Aurelia Design System.

## Requisitos

- Docker y Docker Compose (recomendado para levantar todo el stack).
- Alternativamente, para desarrollo sin Docker: Python 3.12+ y Node.js 20+.

## Puesta en marcha (Docker)

```bash
cp .env.example .env   # ya viene copiado como .env en esta entrega
docker compose up --build
```

Al terminar de levantar:

- Dashboard: http://localhost:3000
- API: http://localhost:8000
- Documentación OpenAPI: http://localhost:8000/docs
- Liveness: http://localhost:8000/health/live
- Readiness (chequea Postgres y Redis): http://localhost:8000/health/ready

`docker compose down` detiene todo. `make clean` elimina además volúmenes e
imágenes locales.

## Desarrollo sin Docker

**Backend:**

```bash
cd apps/api
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
uvicorn app.main:app --reload
```

Sin Postgres/Redis corriendo localmente, `/health/live` responde igual;
`/health/ready` informa `"degraded"` con el detalle de qué servicio falta —
no rompe la aplicación.

**Frontend:**

```bash
cd apps/dashboard
npm install
npm run dev
```

## Testing y calidad

```bash
make test    # pytest (backend)
make lint    # ruff (backend) + eslint (frontend)
```

## Estructura del monorepo

```
.
├── apps/
│   ├── api/                  # FastAPI
│   │   ├── app/
│   │   │   ├── api/routes/   # health.py, products.py
│   │   │   ├── core/         # config.py, logging.py
│   │   │   ├── db/           # session.py, base.py
│   │   │   ├── models/       # product.py (SQLAlchemy)
│   │   │   ├── schemas/      # product.py (Pydantic)
│   │   │   └── main.py
│   │   ├── tests/             # pytest + SQLite en memoria
│   │   ├── pyproject.toml
│   │   └── Dockerfile
│   └── dashboard/             # Next.js 16 (App Router)
│       ├── app/                # layout.tsx, page.tsx, globals.css
│       ├── lib/api.ts           # cliente HTTP hacia la API
│       ├── package.json
│       └── Dockerfile
├── .github/workflows/ci.yml   # lint + tests + build de imágenes
├── docker-compose.yml
├── Makefile
├── .env.example
└── package.json                # workspace root (npm)
```

## Variables de entorno

Ver `.env.example` para el listado completo y comentado. Las más relevantes:

| Variable | Uso |
|---|---|
| `DATABASE_URL` | Conexión async a PostgreSQL (SQLAlchemy + asyncpg) |
| `REDIS_URL` | Conexión a Redis |
| `SECRET_KEY` | Clave de firma — **cambiar antes de producción** |
| `NEXT_PUBLIC_API_URL` | URL de la API que consume el dashboard |

## Estado verificado

Todo lo listado abajo se ejecutó realmente en el entorno de build, no es una
descripción aspiracional:

- ✅ Backend: `pip install -e ".[dev]"` sin errores.
- ✅ Backend: 4/4 tests (`pytest`) en verde, incluyendo casos de error (409
  slug duplicado, 404 producto inexistente/UUID inválido).
- ✅ Backend: `ruff check` sin errores.
- ✅ Backend: servidor real (`uvicorn`) arrancado, `/health/live` y
  `/openapi.json` respondidos correctamente; `/health/ready` degrada con
  gracia cuando Postgres/Redis no están disponibles (no crashea).
- ✅ Frontend: `npm install` sin conflictos de dependencias ni
  vulnerabilidades reportadas (se corrigió una dependencia inicial de
  Next.js 14.2.5, que tenía CVEs sin parche por fin de soporte; el proyecto
  quedó en Next.js 16.2.10 / React 19.2.4, líneas con soporte activo).
- ✅ Frontend: `next build` sin errores de compilación ni de TypeScript.
- ✅ Frontend: `eslint` sin errores ni warnings.
- ✅ Frontend: servidor de producción (`next start`) arrancado y probado —
  la página degrada con gracia (sin romper) cuando la API no está disponible.
- ✅ `docker-compose.yml` y `ci.yml` validados como YAML bien formado.
- ⚠️ No verificado en este entorno: `docker compose up` de punta a punta
  (el sandbox de esta sesión no tiene Docker disponible). Los Dockerfiles
  siguen las prácticas estándar (multi-stage, non-root user, healthchecks)
  pero se recomienda correr `docker compose up --build` una vez clonado el
  repo como último paso de verificación.

## Próximos sprints

- **Sprint 002 — Core Platform:** autenticación, modelos de dominio
  adicionales (colecciones, licencias de producto), migraciones con Alembic.
- **Sprint 003 — Dashboard:** vistas reales sobre `apps/dashboard` (listado
  de productos, métricas), usando los 26 componentes ya especificados en el
  Design System (Navegación, Dashboard, Calendarios, Portadas).
- **Sprint 004 — AI Runtime:** agentes sobre pgvector para automatizar
  generación de contenido y componentes.
- **Sprint 005 — Product Factory / Sprint 006 — MVP.**
