"""Base declarativa de SQLAlchemy para todos los modelos de Aurelia OS."""
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass
