"""Esquemas Pydantic para el recurso Producto."""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ProductBase(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    slug: str = Field(min_length=1, max_length=220)
    category: str = Field(min_length=1, max_length=80)
    price_usd: float = Field(ge=0)
    status: str = Field(default="draft", pattern="^(draft|active|archived)$")


class ProductCreate(ProductBase):
    pass


class ProductRead(ProductBase):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    created_at: datetime
