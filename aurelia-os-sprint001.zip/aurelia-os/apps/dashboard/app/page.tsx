import { getApiHealth } from "@/lib/api";

export default async function DashboardPage() {
  const health = await getApiHealth();

  return (
    <main
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: "24px",
        padding: "24px",
      }}
    >
      <h1
        style={{
          fontSize: "40px",
          fontWeight: 700,
          letterSpacing: "0.02em",
          margin: 0,
        }}
      >
        AURELIA <span style={{ color: "var(--primary-gold)" }}>OS</span>
      </h1>
      <p style={{ color: "var(--text-secondary)", margin: 0 }}>
        Panel de control — Sprint 001
      </p>

      <div
        style={{
          border: `1px solid var(--border)`,
          background: "var(--surface)",
          borderRadius: "12px",
          padding: "20px 28px",
          minWidth: "320px",
        }}
      >
        <StatusRow
          label="API"
          ok={health.status === "ok" || health.status === "degraded"}
        />
        {health.checks &&
          Object.entries(health.checks).map(([key, value]) => (
            <StatusRow key={key} label={key} ok={value === "ok"} detail={value} />
          ))}
        {health.status === "unreachable" && (
          <p style={{ color: "var(--warning)", fontSize: "14px", marginTop: "12px" }}>
            No se pudo contactar la API en {process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000"}.
            Verificá que el servicio esté corriendo (docker compose up).
          </p>
        )}
      </div>
    </main>
  );
}

function StatusRow({
  label,
  ok,
  detail,
}: {
  label: string;
  ok: boolean;
  detail?: string;
}) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "8px 0",
        borderBottom: "1px solid var(--divider)",
      }}
    >
      <span style={{ color: "var(--text-secondary)", fontSize: "14px" }}>
        {label}
      </span>
      <span
        style={{
          color: ok ? "var(--success)" : "var(--error)",
          fontSize: "13px",
          fontWeight: 600,
        }}
      >
        {detail ?? (ok ? "ok" : "error")}
      </span>
    </div>
  );
}
