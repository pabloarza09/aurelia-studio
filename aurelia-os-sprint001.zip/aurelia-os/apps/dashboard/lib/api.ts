const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export type HealthStatus = {
  status: string;
  service?: string;
  version?: string;
  checks?: Record<string, string>;
};

/**
 * Consulta el estado del backend. Nunca lanza: si la API no responde,
 * devuelve un estado "unreachable" para que la UI se degrade con gracia.
 */
export async function getApiHealth(): Promise<HealthStatus> {
  try {
    const res = await fetch(`${API_URL}/health/ready`, {
      cache: "no-store",
      signal: AbortSignal.timeout(3000),
    });
    if (!res.ok) {
      return { status: "unreachable" };
    }
    return (await res.json()) as HealthStatus;
  } catch {
    return { status: "unreachable" };
  }
}
